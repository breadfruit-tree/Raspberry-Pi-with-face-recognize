package com.example.pi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class MainActivity extends AppCompatActivity {

    //控件定义
    EditText edGateIp, edGateSn;
    Button btnSearch, btnLogin;

    //消息机制
    private Handler messageHandler;

    //开辟一个socket
    Socket socket = null;

    OutputStream OutputStream = null;//定义数据输出流，用于发送数据
    BufferedReader bufferedReader;//声明输入流对象
    InputStream InputStream = null;//定义数据输入流，用于接收数据

    //定义一个逻辑变量，用于判断服务器连接状态
    boolean isConnected = false;

    //用于控制读数据线程是否执行
    boolean RD = false;


    //测试区域
    Button fs;
    EditText sjfs;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //控件绑定
        edGateIp = findViewById(R.id.edGateIp);
        edGateSn = findViewById(R.id.edGateSn);
        btnSearch = findViewById(R.id.btnSearch);
        btnLogin = findViewById(R.id.btnLogin);

        fs=findViewById(R.id.fs);
        sjfs=findViewById(R.id.sjfs);



        //自动填写按钮事件
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //自动填写服务器固定的IP地址跟端口号
                edGateIp.setText("192.168.12.1");
                edGateSn.setText("7654");
            }
        });

        //连接服务器按钮事件
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //容错机制
                //取出文本框内容，用来判断输入框是否为空
                String ip = edGateIp.getText().toString();
                String sn = edGateSn.getText().toString();

                if((ip== null || ip.length() == 0 )&& (sn== null || sn.length() == 0))
                    Toast.makeText(MainActivity.this, "IP地址、端口号不能为空", Toast.LENGTH_SHORT).show();
                else if(ip== null || ip.length() == 0)
                    Toast.makeText(MainActivity.this, "IP地址不能为空", Toast.LENGTH_SHORT).show();
                else if(sn== null || sn.length() == 0)
                    Toast.makeText(MainActivity.this, "端口号不能为空", Toast.LENGTH_SHORT).show();

                else {
                    //判断服务器连接状态
                    if (isConnected != true) {
                        //创建一条新的Socket连接
                        new ClientThread().start();
                        //按钮文字改变
                        btnLogin.setText("断开连接");
                        //页面消息
                        Toast.makeText(MainActivity.this, "服务器连接成功！", Toast.LENGTH_SHORT).show();
                        //二次判断，服务器是否已连接上
                        if (socket == null) {
                            //没连接的话，按钮文字改为连接服务器，页面消息提示
                            btnLogin.setText("连接服务器");
                            Toast.makeText(MainActivity.this, "连接错误，请检查WiFi是否连上，IP、端口是否输入正确！", Toast.LENGTH_SHORT).show();
                        }

                    } else {
                        //按钮按下的时候已在连接情况下，服务器断开连接
                        if (socket != null) {
                            try {
                                //退出服务器
                                socket.close();
                                //服务器状态改为空
                                socket = null;
                                //服务器连接转态改为空
                                isConnected = false;
                                //读数据线程不执行
                                RD = false;

                                btnLogin.setText("连接服务器");
                                //页面文字显示
                                Toast.makeText(MainActivity.this, "与服务器断开连接！", Toast.LENGTH_SHORT).show();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            }
        });

        //发送按钮按下状态
        fs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //这里可以用线程也可以不用线程
                String zt = btnLogin.getText().toString();


                if(zt == "断开连接"){
                    new sj().start();
                    if(sjfs != null && sjfs.length() > 0){
                        //handlerMessage处理发送信息刷新UI界面
                        Message msgMessage =new Message();
                        msgMessage.obj=sjfs.getText().toString();
                        msgMessage.what=0;
                        messageHandler.sendMessage(msgMessage);
                    }
                    else //页面文字显示
                        Toast.makeText(MainActivity.this, "发送的数据不能为空！", Toast.LENGTH_SHORT).show();
                }
                else //页面文字显示
                    Toast.makeText(MainActivity.this, "未连接服务器，请先连接！", Toast.LENGTH_SHORT).show();
            }
        });


        //消息处理机制
        messageHandler = new Handler() { // 等待socket连接成功
            @Override
            public void handleMessage(android.os.Message msgMessage) {
                String sendString="";
                String receiveString="";

                switch (msgMessage.what) {
                    case 0:
                        //append追加显示数据，之前数据不会被替换
                        sendString="用户端发送："+msgMessage.obj.toString()+"\n";
                        sjfs.append(sendString);
                        break;


                    default:
                        break;
                }
            }
        };
    }

    //用线程创建Socket连接,线程不允许更新UI(用Handler实现)
    public class ClientThread extends Thread{
        public void run(){
            //定义两个变量用于储存ip跟端口号
            InetAddress GateIp;
            int GateSn;
            try {
                //判断socket的状态，防止重复执行
                if(socket == null){
                    //获取输入的IP地址
                    GateIp = InetAddress.getByName(edGateIp.getText().toString());
                    //获取输入的端口
                    GateSn = Integer.valueOf(edGateSn.getText().toString());
                    //新建一个socket,连接
                    socket = new Socket(GateIp,GateSn);
                    ///获取socket的输出流，接收数据
                    InputStream = socket.getInputStream();


                    //取得输入流、输出流
                    //取得输入流、输出流
                    bufferedReader=new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    OutputStream=socket.getOutputStream();

                    //接收数据可用子线程也可直接在此线程操作
                    char[] buffer=new char[256];//定义数组接收输入流数据
                    String bufferString="";//定义一个字符接收数组数据
                    int conut =0;//初始化buffer数组长度为0
                    int tag=0;//初识写入数组的位置

                    isConnected=true;

                    //死循环重复接收输入流数据并进行处理
                    while (true) {
                        //当输入流写入buffer数组的长度大于0时即接收到数据时
                        while ((conut=bufferedReader.read(buffer))>0) {
                            //将buffer数组的数据全部写入bufferString字符类型
                            while ( tag<buffer.length) {
                                bufferString=bufferString+buffer[tag];
                                tag++;
                            }
                            //将数据给messageHandler刷新UI界面
                            Message msgMessage =new Message();
                            msgMessage.obj=bufferString;
                            msgMessage.what=1;
                            messageHandler.sendMessage(msgMessage);
                            //初始化数据，以便处理下一条输入流信息
                            tag=0;
                            bufferString="";
                        }
                    }
                }
                //出错提示
                //UnknownHostExceptionDNS解析出错
                //IOException读写文件异常
            } catch (UnknownHostException e) {
                //在命令行打印异常信息在程序中出错的位置及原因
                e.printStackTrace();
            } catch (IOException e) {
                //在命令行打印异常信息在程序中出错的位置及原因
                e.printStackTrace();
            }
        }
    }


    //向服务器发送数据子程序
    public class sj extends Thread {
        public void run() {
            //判断连接状态
            if (socket != null) {
                try {
                    //判断输入框是否为空
                    if (sjfs != null && sjfs.length() > 0) {
                        //输入框内容转码后向服务器发送
                        OutputStream.write((sjfs.getText().toString()+"\n").getBytes("utf-8"));
                        //清空缓冲区
                        OutputStream.flush();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } // 连接输出流
            }
        }
    }



}
